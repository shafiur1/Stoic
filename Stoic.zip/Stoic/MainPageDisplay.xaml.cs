﻿using Binding;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using MimeTypes;
using System.Net;



namespace Stoic
{
    /// <summary>
    /// Interaction logic for MainPageDisplay.xaml
    /// </summary>
    public partial class MainPageDisplay : Window
    {
        public string myString { get; set; }
        public List<Class1Main> res;
        private DispatcherTimer timerVideoTime;

        public MainPageDisplay(string value)
        {
            InitializeComponent();
            this.myString = value;
            res = Class1MainManager.GetRequestcategories(value.ToString());
            //listView.ItemsSource = res;
            //MyMainList.ItemsSource = res;

            //fdViewer.Visibility = Visibility.Collapsed;

            //string[] fileNames = Assembly.GetExecutingAssembly().GetManifestResourceNames();

            //using (FileStream fileStream = File.Create(@"c:\temp\" + "minions.mp4"))
            //    {
            //        Assembly.GetExecutingAssembly().GetManifestResourceStream("minions.mp4").CopyTo(fileStream);
            //    }

            imaContent.Visibility = Visibility.Collapsed;
            List<Person> persons = new List<Person>();
            List<Person> personsContent = new List<Person>();
            foreach (Class1Main cm in res)
            {
                Person person1 = new Person() { Name = cm.category_name, Desc = cm.category_description, img = "/Images/Graduation.png", contennt = null };

                foreach (Enrolled_Course ec in cm.enrolled_course)
                {
                    Person person2 = new Person() { Name = ec.shortname, Desc = ec.shortname, img = "/Images/Student_Card.png", contennt = null };
                    foreach (LevelMain lm in ec.level)
                    {
                        Person person3 = new Person() { Name = lm.name, Desc = lm.summary, img = "/Images/Medal.png", contennt = null };
                        foreach (ModuleMain mm in lm.modules)
                        {
                            Person person4 = new Person() { Name = mm.name, Desc = mm.modname, img = "/Images/Examination.png", contennt = mm.contents };
                            foreach (ContentMain cma in mm.contents)
                            {
                                Person personsContent1 = new Person() { Name = cma.filename, Desc = cma.fileurl, img = "/Images/Examination.png" };
                                personsContent.Add(personsContent1);
                            }
                            person3.Children.Add(person4);
                        }

                        person2.Children.Add(person3);
                    }

                    person1.Children.Add(person2);
                }
                persons.Add(person1);

            }

            trvPersons.ItemsSource = persons;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        #region MediaPlayer


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            timerVideoTime = new DispatcherTimer();
            timerVideoTime.Interval = TimeSpan.FromSeconds(0.1);
            timerVideoTime.Tick += new EventHandler(timer_Tick);
            minionPlayer.Stop();
            Position.Visibility = Visibility.Hidden;

            mainGrid.Visibility = Visibility.Collapsed;
            fdViewer.Visibility = Visibility.Visible;
        }
        private void minionPlayer_MediaOpened(object sender, RoutedEventArgs e)
        {
            Position.Minimum = 0;
            Position.Maximum = minionPlayer.NaturalDuration.TimeSpan.TotalSeconds;
            Position.Visibility = Visibility.Visible;
        }

        // Show the play position in the ScrollBar and TextBox.
        private void ShowPosition()
        {
            Position.Value = minionPlayer.Position.TotalSeconds;
            txtPosition.Text = minionPlayer.Position.TotalSeconds.ToString("0.0");
        }

        // Enable and disable appropriate buttons.
        private void EnableButtons(bool is_playing)
        {
            if (is_playing)
            {
                btnPlay.IsEnabled = false;
                btnPause.IsEnabled = true;
                btnPlay.Opacity = 0.5;
                btnPause.Opacity = 1.0;
            }
            else
            {
                btnPlay.IsEnabled = true;
                btnPause.IsEnabled = false;
                btnPlay.Opacity = 1.0;
                btnPause.Opacity = 0.5;
            }
            timerVideoTime.IsEnabled = is_playing;
        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.Play();
            EnableButtons(true);
        }
        private void btnPause_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.Pause();
            EnableButtons(false);
        }
        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.Stop();
            EnableButtons(false);
            ShowPosition();
        }
        private void btnRestart_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.Stop();
            minionPlayer.Play();
            EnableButtons(true);
        }
        private void btnFaster_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.SpeedRatio *= 1.5;
        }
        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.Position += TimeSpan.FromSeconds(10);
            ShowPosition();
        }
        private void btnSlower_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.SpeedRatio /= 1.5;
        }
        private void btnPrevious_Click(object sender, RoutedEventArgs e)
        {
            minionPlayer.Position -= TimeSpan.FromSeconds(10);
            ShowPosition();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            ShowPosition();
        }

        private void btnSetPosition_Click(object sender, RoutedEventArgs e)
        {
            TimeSpan timespan = TimeSpan.FromSeconds(double.Parse(txtPosition.Text));
            minionPlayer.Position = timespan;
            ShowPosition();
        }
        #endregion


        private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            Position.Visibility = Visibility.Hidden;
            mainGrid.Visibility = Visibility.Collapsed;
            fdViewer.Visibility = Visibility.Visible;
            
            minionPlayer.Stop();

            string str = e.NewValue.ToString();

            var parentPerson = (trvPersons.SelectedItem as Person);
            System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex("<[^>]*>");
            FlowDocument doc = new FlowDocument();

            Paragraph p = new Paragraph(new Run(parentPerson.Name));
            p.FontSize = 25;
            doc.Blocks.Add(p);
            //doc.Blocks.Add(p);

            p = new Paragraph(new Run(rx.Replace(parentPerson.Desc.Replace("<p>", "\n"), "")));
            p.FontSize = 15;
            p.FontStyle = FontStyles.Italic;
            p.TextAlignment = TextAlignment.Left;
            p.Foreground = Brushes.Gray;

            doc.Blocks.Add(p);


            //var doomed = res.FirstOrDefault(p => p.enrolled_course. == item.ToString()); 
            if (parentPerson.contennt != null)
            {
                List<Person> personsContent = new List<Person>();
                foreach (ContentMain cma in parentPerson.contennt)
                {
                    Person personsContent1 = new Person() { Name = cma.filename, Desc = cma.fileurl, img = "/Images/Examination.png" };
                    personsContent.Add(personsContent1);
                }
                lvDataBinding.ItemsSource = personsContent;
                //Image image = new Image();
                //BitmapImage bimg = new BitmapImage();
                //bimg.BeginInit();
                //bimg.UriSource = "";//new Uri("c:\temp\image.png", UriKind.Absolute);
                //bimg.EndInit();
                //image.Source = bimg;
                //doc.Blocks.Add(new BlockUIContainer(image));
            }

            fdViewer.Visibility = Visibility.Visible;

            myBrowser.Refresh();
            var stringhtm = parentPerson.Name + "<br/>" + parentPerson.Desc;
            myBrowser.DocumentText = stringhtm;

            //myBrowser.Navigate();
            //this.myBrowser.NavigateToString =parentPerson.Name+"<br/>"+ parentPerson.Desc;
            ////myBrowser.DocumentText = "0";
            ////myBrowser.Document.OpenNew(true);
            //myBrowser.Document.Write(parentPerson.Name + "<br/>" + parentPerson.Desc);
            //myBrowser.Refresh();

            //fdViewer.Document = doc;

            //txtDesc.Text = doc; //parentPerson.Desc.Replace("<p>", "\n").Replace("</p>", " ");


            //presenter.Text = e.NewValue;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Position.Visibility = Visibility.Visible;

            mainGrid.Visibility = Visibility.Visible;
            fdViewer.Visibility = Visibility.Collapsed;
            //string pdfurl1 = (String)((Directory.GetCurrentDirectory() + "minions.mp4"));
            //Uri str = new Uri(Directory.GetCurrentDirectory() + "minions.mp4");
            //minionPlayer.Source = str;
            Uri str = new Uri(AppDomain.CurrentDomain.BaseDirectory + "minions.mp4");//new Uri("Videos/minions.mp4");
            minionPlayer.Source = str;
        }


        private void btnCourseA_Click(object sender, RoutedEventArgs e)
        {
            FlowDocument doc = new FlowDocument();

            var item = (sender as FrameworkElement).Tag;


            string filename = "";
            string mimeType = "";

            filename = GetFileName(item.ToString());

            if (filename != "")
                mimeType = MimeTypeMap.GetMimeType(filename);
            if (mimeType == "application/octet-stream")
            {
                Position.Visibility = Visibility.Hidden;
                mainGrid.Visibility = Visibility.Collapsed;
                fdViewer.Visibility = Visibility.Visible;
                minionPlayer.Stop();

                fdViewer.Visibility = Visibility.Collapsed;
               

                myBrowser.Navigate(new Uri(item.ToString()));
                

                

            }



        }
        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }
        private string GetFileName(string hrefLink)
        {
            string[] parts = hrefLink.Split('/');
            string fileName = "";

            if (parts.Length > 0)
                fileName = parts[parts.Length - 1];
            else
                fileName = hrefLink;

            return fileName;
        }


    }


    public class Person : TreeViewItemBase
    {
        public Person()
        {
            this.Children = new ObservableCollection<Person>();
        }

        public string Name { get; set; }

        public string Desc { get; set; }
        public string img { get; set; }
        public List<ContentMain> contennt = new List<ContentMain>();

        public ObservableCollection<Person> Children { get; set; }
    }

    public class TreeViewItemBase : INotifyPropertyChanged
    {
        private bool isSelected;
        public bool IsSelected
        {
            get { return this.isSelected; }
            set
            {
                if (value != this.isSelected)
                {
                    this.isSelected = value;
                    NotifyPropertyChanged("IsSelected");
                }
            }
        }

        private bool isExpanded;
        public bool IsExpanded
        {
            get { return this.isExpanded; }
            set
            {
                if (value != this.isExpanded)
                {
                    this.isExpanded = value;
                    NotifyPropertyChanged("IsExpanded");
                }
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
    }

}
