﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using App12.Class.BLL;
using System.Net;
using System.IO;




namespace Stoic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private  void Button_Click(object sender, RoutedEventArgs e)
        {
            if (txtUserName.Text == "")
            {
                txtError.Text = "Please enter username!";
                return;
            }
            else if (txtPassword.Password == "")
            {
                txtError.Text = "Please enter password!";
                return;
            }
            
            string  result =GetRequest();
            MainPageDisplay objMain = new MainPageDisplay(result.ToString());
           
            objMain.Show();
            this.Close(); 
         
          
            //var page = new Page(MainPageDisplay);
            //MainWindow.NavigatePage(page); 
            //MainWindow.Navigate(typeof(MainPageDisplay), result);
        }
        private void CloseAllWindows()
        {
            for (int intCounter = App.Current.Windows.Count - 1; intCounter > 0; intCounter--)
                App.Current.Windows[intCounter].Close();
        }
        public string GetRequest()
        {
            //Uri geturi = new Uri("http://ec2-13-126-140-65.ap-south-1.compute.amazonaws.com/stoic//api_app/routerpost.php?type=login&user=testtest&password=wW@9044472181"); //replace your url  
            //Uri geturi = new Uri("http://ec2-13-126-140-65.ap-south-1.compute.amazonaws.com/stoic//api_app/routerpost.php?type=login&user=" + txtUserName.Text + "&password=" + txtPassword.Password + ""); //replace your url 

            string responseText;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://ec2-13-126-140-65.ap-south-1.compute.amazonaws.com/stoic//api_app/routerpost.php?type=login&user=" + txtUserName.Text + "&password=" + txtPassword.Password + "");
            request.ContentType= "application/json";
            request.Headers.Add("Authtoken", "8l45phQR7ZktSRFE7Z6CqRyETrlUaRv3");
            

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                using (StreamReader responseStream = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding("utf-8")))
                {
                    responseText = responseStream.ReadToEnd();
                }
            }

            //return responseText;
            //System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();

            //client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");

            //client.DefaultRequestHeaders.Add("Authtoken", "8l45phQR7ZktSRFE7Z6CqRyETrlUaRv3");
            //System.Net.Http.HttpResponseMessage responseGet = await client.GetAsync(geturi);
            //string response = await responseGet.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<LoginD>(responseText);
            return result.message;
        }
        
    }
}
