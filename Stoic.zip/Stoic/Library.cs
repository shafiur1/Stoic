﻿using System;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows;

public class Library
{
    public delegate void PlayingEvent();
    public event PlayingEvent Playing;

    private DispatcherTimer timer = new DispatcherTimer();

    //public void Init()
    //{
    //    timer.Tick += (object sender, object e) =>
    //    {
    //        if (this.Playing != null) Playing();
    //    };
    //}

    public void Timer(bool enabled)
    {
        if (enabled) timer.Start(); else timer.Stop();
    }

    //public void Go(ref MediaElement display, string value, KeyRoutedEventArgs args)
    //{
    //    if (args.Key == Windows.System.VirtualKey.Enter)
    //    {
    //        try
    //        {
    //            display.Source = new Uri(value, UriKind.Absolute);
    //            display.Play();
    //        }
    //        catch
    //        {

    //        }
    //    }
    //}
}