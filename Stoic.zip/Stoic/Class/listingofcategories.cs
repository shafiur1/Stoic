﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App12.Class.BLL
{


    public class listingofcategories
    {


        public int id { get; set; }
        public string name { get; set; }
        public string idnumber { get; set; }
        public string description { get; set; }
        public int descriptionformat { get; set; }
        public int parent { get; set; }
        public int sortorder { get; set; }
        public int coursecount { get; set; }
        public int visible { get; set; }
        public int visibleold { get; set; }
        public int timemodified { get; set; }
        public int depth { get; set; }
        public string path { get; set; }
        public object theme { get; set; }

        public List<listingofcategories> subCat = new List<listingofcategories>();


    }

}
