﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Binding1
{
    public class Car
    {
        public int CarId
        {
            get;
            set;
        }
        public string Category
        {
            get;
            set;
        }
        public string Model
        {
            get;
            set;
        }
        public string CategoryDesc
        {
            get;
            set;
        }
        public  List<SubItems1> SubItemsList { get; set; }

    }

    public class SubItems1
    {
        public string SubItemName { get; set; }
        public string SubItemDesc { get; set; }
        public List<SubSubItems1> SubSubItemsList { get; set; }
    }

    public class SubSubItems1
    {
        public string SubSubItemName { get; set; }
        public List<SubSubSubItems1> SubSubSubItemsList { get; set; }
    }


    public class SubSubSubItems1
    {
        public string SubSubSubItemName { get; set; }
    }

    public class SubSubSubCarManager
    {
        public static List<SubSubSubItems1> GetSubSubSubCars()
        {
            var subsubcars = new List<SubSubSubItems1>();

            subsubcars.Add(new SubSubSubItems1
            {
                SubSubSubItemName = "Lession 1",

            });
            subsubcars.Add(new SubSubSubItems1
            {
                SubSubSubItemName = "Lession 2",

            });
            subsubcars.Add(new SubSubSubItems1
            {
                SubSubSubItemName = "Lession 3",

            });


            return subsubcars;
        }
    }
    public class SubSubCarManager
    {
        public static List<SubSubItems1> GetSubSubCars()
        {
            var subcars = new List<SubSubItems1>();
            List<SubSubSubItems1> ssscar = SubSubSubCarManager.GetSubSubSubCars();
            subcars.Add(new SubSubItems1
            {
                SubSubItemName = "Module 1",
                SubSubSubItemsList= ssscar

            });
            subcars.Add(new SubSubItems1
            {
                SubSubItemName = "Module 2",
                SubSubSubItemsList = ssscar

            });


            return subcars;
        }
    }
    public  class subCarManager
    {
        public static List<SubItems1> GetSubCars()
        {
            var subcars = new List<SubItems1>();
            List<SubSubItems1> sscar = SubSubCarManager.GetSubSubCars();
            subcars.Add(new SubItems1
            {
                SubItemName = "level1",
                SubSubItemsList = sscar

            });
            subcars.Add(new SubItems1
            {
                SubItemName = "level2",
                SubSubItemsList = sscar

            });


            return subcars;
        }
    }
    public class CarManager
    {
       
        public static List<Car> GetCars()
        {
            List<SubItems1> scar = subCarManager.GetSubCars();
            var cars = new List<Car>();
            cars.Add(new Car
            {
                Category = "Value Investing",
                Model = "2014",
                CategoryDesc = "I hope you enjoy this sample and it proves helpful for you to better understand how to implement responsive design on UWP. Notice that throughout all the demos (except the last one) there was no specific UI being built for a particular device or device family.\n I hope you enjoy this sample and it proves helpful for you to better understand how to implement responsive design on UWP. Notice that throughout all the demos (except the last one) there was no specific UI being built for a particular device or device family. \n I hope you enjoy this sample and it proves helpful for you to better understand how to implement responsive design on UWP. Notice that throughout all the demos (except the last one) there was no specific UI being built for a particular device or device family.",
                SubItemsList = scar
            });
            cars.Add(new Car
            {
                Category = "Value Investing2",
                Model = "2008",
                CategoryDesc = "I hope you enjoy this sample and it proves helpful for you to better understand how to implement responsive design on UWP",
                SubItemsList = scar
            });
            

          
            return cars;
        }
    }


}