﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Binding
{





    public class Class1Main
    {
        public string category_id { get; set; }
        public string category_name { get; set; }
        public string category_description { get; set; }
        public List<Enrolled_Course> enrolled_course = new List<Enrolled_Course>();
    }

    public class Enrolled_Course
    {
        public string id { get; set; }
        public string category { get; set; }
        public string sortorder { get; set; }
        public string shortname { get; set; }
        public string fullname { get; set; }
        public string idnumber { get; set; }
        public string startdate { get; set; }
        public string visible { get; set; }
        public string defaultgroupingid { get; set; }
        public string groupmode { get; set; }
        public string groupmodeforce { get; set; }
        public string ctxid { get; set; }
        public string ctxpath { get; set; }
        public string ctxdepth { get; set; }
        public string ctxlevel { get; set; }
        public string ctxinstance { get; set; }
        public List<LevelMain> level = new List<LevelMain>();
    }

    public class LevelMain
    {
        public int id { get; set; }
        public string name { get; set; }
        public int visible { get; set; }
        public string summary { get; set; }
        public int summaryformat { get; set; }
        public int section { get; set; }
        public int hiddenbynumsections { get; set; }
        public List<ModuleMain> modules = new List<ModuleMain>();
    }

    public class ModuleMain
    {
        public int id { get; set; }
        public string url { get; set; }
        public string name { get; set; }
        public int instance { get; set; }
        public int visible { get; set; }
        public string modicon { get; set; }
        public string modname { get; set; }
        public string modplural { get; set; }
        public object availability { get; set; }
        public int indent { get; set; }
        public List<ContentMain> contents = new List<ContentMain>();
    }

    public class ContentMain
    {
        public string type { get; set; }
        public string filename { get; set; }
        public string filepath { get; set; }
        public int filesize { get; set; }
        public string fileurl { get; set; }
        public int? timecreated { get; set; }
        public int timemodified { get; set; }
        public int sortorder { get; set; }
        public int? userid { get; set; }
        public string author { get; set; }
        public string license { get; set; }
    }

    public class Class1MainManager
    {

        public static List<Class1Main> GetRequestcategories(string key)
        {
            string responseText;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://ec2-13-126-140-65.ap-south-1.compute.amazonaws.com/stoic//api_app/routerpost.php?type=enrolluser&token=" + key + "");
            request.ContentType = "application/json";
            request.Headers.Add("Authtoken", "8l45phQR7ZktSRFE7Z6CqRyETrlUaRv3");


            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                using (StreamReader responseStream = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding("utf-8")))
                {
                    responseText = responseStream.ReadToEnd();
                }
            }

            //return responseText;
            //System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();

            //client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");

            //client.DefaultRequestHeaders.Add("Authtoken", "8l45phQR7ZktSRFE7Z6CqRyETrlUaRv3");
            //System.Net.Http.HttpResponseMessage responseGet = await client.GetAsync(geturi);
            //string response = await responseGet.Content.ReadAsStringAsync();
            List<Class1Main> result = JsonConvert.DeserializeObject<List<Class1Main>>(responseText);
            return result;
            
            ////Uri geturi = new Uri("http://ec2-13-126-140-65.ap-south-1.compute.amazonaws.com/stoic/webservice/rest/server.php?wstoken=" + key + "&wsfunction=core_course_get_categories &moodlewsrestformat=json"); //replace your url  
            //Uri geturi = new Uri("http://ec2-13-126-140-65.ap-south-1.compute.amazonaws.com/stoic//api_app/routerpost.php?type=enrolluser&token=" + key + ""); //replace your url  
            //System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();
            //client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");
            //client.DefaultRequestHeaders.Add("Authtoken", "8l45phQR7ZktSRFE7Z6CqRyETrlUaRv3");
            //System.Net.Http.HttpResponseMessage responseGet = await client.GetAsync(geturi);
            //string response = await responseGet.Content.ReadAsStringAsync();
            //List<Class1Main> result = JsonConvert.DeserializeObject<List<Class1Main>>(response);
            //return result;
        }
    }
}
